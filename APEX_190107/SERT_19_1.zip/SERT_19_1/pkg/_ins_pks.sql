PROMPT == SV_SEC_LOG_EXCEPTION_API
@pkg/sv_sec_log_exception_api.pls
/
SHOW ERRORS 
/

PROMPT == SV_SEC_ERROR
@pkg/sv_sec_error.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC
@pkg/sv_sec.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_UTIL
@pkg/sv_sec_util.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_PREF
@pkg/sv_sec_pref.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_HELP
@pkg/sv_sec_help.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_RULES
@pkg/sv_sec_rules.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_EXPORT
@pkg/sv_sec_export.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_IMPORT
@pkg/sv_sec_import.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_COLLECTIONS
@pkg/sv_sec_collections.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_EVENTS
@pkg/sv_sec_log_events.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_LOG_EVENTS
@pkg/sv_sec_log_events.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_FILE_MGR
@pkg/sv_sec_file_mgr.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_SCHEDULER
@pkg/sv_sec_scheduler.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_EXCEPTION
@pkg/sv_sec_exception.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_ADMIN
@pkg/sv_sec_admin.pks
/
SHOW ERRORS 
/

PROMPT == PL_FPDF
@pkg/pl_fpdf.pks
/
SHOW ERRORS
/

PROMPT == SV_SEC_RPT_UTIL
@pkg/sv_sec_rpt_util.pks
/
SHOW ERRORS
/

PROMPT == SV_SEC_RPT_GENERIC
@pkg/sv_sec_rpt_generic.pks
/
SHOW ERRORS
/

PROMPT == SV_SEC_RPT_CLASS_SUMMARY
@pkg/sv_sec_rpt_class_summary.pks
/
SHOW ERRORS
/

PROMPT == SV_SEC_RPT_MOAR
@pkg/sv_sec_rpt_moar.pks
/
SHOW ERRORS
/
