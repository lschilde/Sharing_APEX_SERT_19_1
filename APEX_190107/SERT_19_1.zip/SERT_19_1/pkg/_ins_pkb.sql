PROMPT == SV_SEC_ERROR
@pkg/sv_sec_error.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC
@pkg/sv_sec.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC_UTIL
@pkg/sv_sec_util.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC_PREF
@pkg/sv_sec_pref.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC_HELP
@pkg/sv_sec_help.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC_RULES
@pkg/sv_sec_rules.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC_IMPORT
@pkg/sv_sec_import.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC_EXPORT
@pkg/sv_sec_export.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC_COLLECTIONS
@pkg/sv_sec_collections.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC_EVENTS
@pkg/sv_sec_log_events.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC_LOG_EVENTS
@pkg/sv_sec_log_events.pks
/
SHOW ERRORS 
/

PROMPT == SV_SEC_FILE_MGR
@pkg/sv_sec_file_mgr.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC_SCHEDULER
@pkg/sv_sec_scheduler.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC_EXCEPTION
@pkg/sv_sec_exception.pkb
/
SHOW ERRORS 
/

PROMPT == SV_SEC_ADMIN
@pkg/sv_sec_admin.pkb
/
SHOW ERRORS 
/

PROMPT == PL_FPDF
@pkg/pl_fpdf.pkb
/
SHOW ERRORS
/

PROMPT == SV_SEC_RPT_UTIL
@pkg/sv_sec_rpt_util.pkb
/
SHOW ERRORS
/

PROMPT == SV_SEC_RPT_GENERIC
@pkg/sv_sec_rpt_generic.pkb
/
SHOW ERRORS
/

PROMPT == SV_SEC_RPT_CLASS_SUMMARY
@pkg/sv_sec_rpt_class_summary.pkb
/
SHOW ERRORS
/

PROMPT == SV_SEC_RPT_MOAR
@pkg/sv_sec_rpt_moar.pkb
/
SHOW ERRORS
/