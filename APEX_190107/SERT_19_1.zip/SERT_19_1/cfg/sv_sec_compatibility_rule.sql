PROMPT == SV_SEC_COMPATIBILITY_RULE
set define on
set define '^'
set concat off
DECLARE 
 l_compatibility_mode varchar2(5);
BEGIN
 select snippet 
    into l_compatibility_mode 
  from sv_sec_snippets 
  where snippet_key = 'COMPATIBILITY_MODE'; 

sv_sec_import.attribute_value(
  p_attribute_key         => 'SV_SET_COMPATIBILITY_MODE',
  p_attribute_set_key     => 'DEFAULT',
  p_value                 => l_compatibility_mode,
  p_result                => 'PASS',
  p_active_flag           => 'Y'
  );

set concat on
COMMIT
/
