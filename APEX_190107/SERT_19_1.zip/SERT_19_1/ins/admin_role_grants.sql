set termout on
set define '^'
set concat on
set concat .
set verify off

-- APEX_ADMINISTRATOR_READ_ROLE GRANTS
GRANT APEX_ADMINISTRATOR_READ_ROLE TO ^parse_as_user
/

GRANT APEX_ADMINISTRATOR_READ_ROLE TO ^esert_user
/


GRANT EXECUTE ON SYS.DBMS_LOB TO  ^esert_user
/

grant inherit privileges on user SYS to ORDS_METADATA;
/